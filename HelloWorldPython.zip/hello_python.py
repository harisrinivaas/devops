def lambda_handler(event, context):
    message = "Hello World - CI CD Lamda Success 2 - Checking Datapipeline"
    return message