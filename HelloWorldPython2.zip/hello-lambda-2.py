def lambda_handler(event, context):
    message = "Hello World - Grand Success"
    return message